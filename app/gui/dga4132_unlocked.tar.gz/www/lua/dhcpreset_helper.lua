return {
	["localdevIP"] = "192.168.1.1",
	["localdevmask"] = "255.255.255.0",
	["localIPv6"] = "0",
	["dhcpState"] = "server",
	["NetworkAddress"] = "192.168.1.0",
	["dhcpStartAddress"] = "192.168.1.100",
	["dhcpEndAddress"] = "192.168.1.249",
	["leaseTime"] = "12h",
	["dnsServer"] = "192.168.1.1",
}
